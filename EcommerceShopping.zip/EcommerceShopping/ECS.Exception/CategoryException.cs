﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ECS.Exception
{
    public class CategoryException:ApplicationException
    {
        public CategoryException() : base() { }

        public CategoryException(string message) : base(message) { }
    }
}
