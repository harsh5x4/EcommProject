﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ECS.Exception
{
    public class ShoppingCartException:ApplicationException
    {
         public ShoppingCartException() : base() { }

         public ShoppingCartException(string message) : base(message) { }
    }
}
