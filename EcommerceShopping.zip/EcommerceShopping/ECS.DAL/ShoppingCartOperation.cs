﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ECS.Entity;
using ECS.Exception;

namespace ECS.DAL
{
    public class ShoppingCartOperation
    {
        static EcomEntities context = new EcomEntities();

        public static int AddToShoppingCart(E_ShoppingCartTable cart)
        {
            int records = 0;

            try
            {
                context.E_ShoppingCartTable.Add(cart);

                records = context.SaveChanges();
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return records;
        }

        public static List<E_ShoppingCartTable> GetAllCartDetails(int CartId)
        {
            List<E_ShoppingCartTable> cartList = null;

            try
            {
                cartList = (from t in context.E_ShoppingCartTable
                                where t.CartId==CartId
                                select t).ToList<E_ShoppingCartTable>();
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return cartList;
        }

        public static int DeleteItemInCart(int RecordId)
        {
            int records = 0;

            try
            {
                var carts = (from c in context.E_ShoppingCartTable
                             where c.RecordId == RecordId
                             select c).FirstOrDefault();

                if (carts != null)
                {
                    context.E_ShoppingCartTable.Remove(carts);
                    records = context.SaveChanges();
                }
                else
                    throw new ShoppingCartException("Record not Deleted.");
            }
            catch (ShoppingCartException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return records;
        }


        public static int UpdateCart(E_ShoppingCartTable updatedcart)
        {
            int records = 0;

            try
            {
                var carts = (from s in context.E_ShoppingCartTable
                                where (s.ProductId == updatedcart.ProductId)
                                select s).FirstOrDefault();

                if (carts != null)
                {
                    carts.Quantity = updatedcart.Quantity;
                    carts.SubTotal = updatedcart.SubTotal;
                    records = context.SaveChanges();
                }
                else
                    throw new ShoppingCartException("Record not found for updation");
            }
            catch (ShoppingCartException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return records;
        }

        public static decimal GetTotal(int ShoppingCartId)
        {
           
            // Multiply product price by quantity of that product to get        
            // the current price for each of those products in the cart.  
            // Sum all product price totals to get the cart total.  
            decimal? total = decimal.Zero;
            total = (decimal?)(from c in context.E_ShoppingCartTable
                               where c.CartId == ShoppingCartId
                               select (int?)c.Quantity * c.UnitCost).Sum();
                              
            return total ?? decimal.Zero;
        }

     
    }
}
