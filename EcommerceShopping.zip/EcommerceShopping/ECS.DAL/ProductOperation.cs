﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ECS.Entity;
using ECS.Exception;

namespace ECS.DAL
{
    public class ProductOperation
    {
        static EcomEntities context = new EcomEntities();


        //Function to Get Products by CategoryId 
        public static List<E_ProductTable> GetProductList(int CatId)
        {
            List<E_ProductTable> prodList = null;

            try
            {
                prodList = (from p in context.E_ProductTable
                            where p.CategoryId == CatId
                            select p).ToList();

            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return prodList;
        }


        //Function to Search Product by Product Name
        public static E_ProductTable SearchProduct(string name)
        {
            E_ProductTable prod = null;

            try
            {
                prod = (from s in context.E_ProductTable
                        where s.ProductName == name
                        select s).FirstOrDefault();
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return prod;
        }

       

    }
}
