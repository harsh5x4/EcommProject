﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ECS.Entity;
using ECS.Exception;


namespace ECS.DAL
{
    public class OrderOperation
    {
        static EcomEntities context = new EcomEntities();


        //Function to Add Order
        public static int AddOrder(E_OrderTable OrdTab)
        {
            int records = 0;

            try
            {
                context.E_OrderTable.Add(OrdTab);

                records = context.SaveChanges();
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return records;
        }

        //Function to Get Order by CustomerId
        public static List<E_OrderTable> GetOrder(int CustId)
        {
            List<E_OrderTable> OrderList = null;

            try
            {
                OrderList = (from t in context.E_OrderTable
                             where t.CustomerId == CustId
                             select t).ToList<E_OrderTable>();
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return OrderList;
        }
    }
}
