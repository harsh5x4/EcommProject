﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ECS.Entity;
using ECS.Exception;

namespace ECS.DAL
{
    /// <summary>
    /// Project Name : ECommerce Online Shopping
    /// Created By : 
    /// Description : This class is to perform Customer Operations
    /// </summary>
    
    public class CustomerOperation
    {
        static EcomEntities context = new EcomEntities();

        //Function to Add Customer
        public static int AddCustomer(E_CustomerTable cust)
        {
            int records = 0;

            try
            {
                context.E_CustomerTable.Add(cust);

                records = context.SaveChanges();
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return records;
        }


        //Function to Search Customer
        public static E_CustomerTable SearchCustomer(string email, string pwd)
        {
            E_CustomerTable cust = null;

            try
            {
                cust = (from s in context.E_CustomerTable
                        where s.Email == email && s.Password == pwd
                        select s).FirstOrDefault();
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return cust;
        }


        //Function to Search Customer By Contact No
        public static E_CustomerTable SearchCustomerByNo(Int64 Number)
        {
            E_CustomerTable cust = null;

            try
            {
                cust = (from s in context.E_CustomerTable
                        where s.Contact == Number 
                        select s).FirstOrDefault();
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return cust;
        }
    }
}
