﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ECS.Entity;
using ECS.Exception;


namespace ECS.DAL
{
    public class OrderDetailsOperation
    {

        static EcomEntities context = new EcomEntities();


        //Function to Add OrderDetails
        public static int AddOrderDetails(E_OrderDetailsTable OrdDetTab)
        {
            int records = 0;

            try
            {
                context.E_OrderDetailsTable.Add(OrdDetTab);

                records = context.SaveChanges();
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return records;
        }

        //Function to Get Order Details by OrderId
        public static List<E_OrderDetailsTable> GetOrderDetails(int OrderId)
        {
            List<E_OrderDetailsTable> OrderList = null;

            try
            {
                OrderList = (from t in context.E_OrderDetailsTable
                            where t.OrderId == OrderId
                             select t).ToList<E_OrderDetailsTable>();
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return OrderList;
        }
    }
}
