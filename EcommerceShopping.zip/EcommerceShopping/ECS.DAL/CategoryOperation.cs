﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ECS.Entity;
using ECS.Exception;

namespace ECS.DAL
{
    /// <summary>
    /// Project Name : ECommerce Online Shopping
    /// Created By : 
    /// Description : This class is to perform Category Operations
    /// </summary>
    
    public class CategoryOperation
    {
        static EcomEntities context = new EcomEntities();


        //Function to Get All Categories
        public static List<E_CategoryTable> GetAllCategories()
        {
            List<E_CategoryTable> catList = null;

            try
            {
                catList = context.E_CategoryTable.ToList<E_CategoryTable>();
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return catList;
        }
    }
}
