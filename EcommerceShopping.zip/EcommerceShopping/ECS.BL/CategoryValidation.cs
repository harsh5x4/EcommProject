﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ECS.Entity;
using ECS.Exception;
using ECS.DAL;

namespace ECS.BL
{
    public class CategoryValidation
    {
        public static List<E_CategoryTable> GetAllCategories()
        {
            List<E_CategoryTable> CatList = new List<E_CategoryTable>();

            try
            {
                CatList = CategoryOperation.GetAllCategories();
            }
            catch (CategoryException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return CatList;
        }
    }
}
