﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ECS.Entity;
using ECS.Exception;
using ECS.DAL;

namespace ECS.BL
{
    public class OrderDetailsValidation
    {
        public static int AddOrderDetails(E_OrderDetailsTable OrdDetTab)
        {
            int records = 0;

            try
            {
                records = OrderDetailsOperation.AddOrderDetails(OrdDetTab);

            }
         
            catch (SystemException ex)
            {
                throw ex;
            }

            return records;
        }


        public static List<E_OrderDetailsTable> GetOrderDetails(int OrderId)
        {
            List<E_OrderDetailsTable> OrderList = new List<E_OrderDetailsTable>();

            try
            {
                OrderList = OrderDetailsOperation.GetOrderDetails(OrderId);
            }
           
            catch (SystemException ex)
            {
                throw ex;
            }

            return OrderList;
        }
    }
}
