﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ECS.Entity;
using ECS.Exception;
using ECS.DAL;

namespace ECS.BL
{
    public class ShoppingCartValidation
    {
        public static int AddToShoppingCart(E_ShoppingCartTable cart)
        {
            int records = 0;

            try
            {
                records = ShoppingCartOperation.AddToShoppingCart(cart);

            }
            catch (ShoppingCartException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return records;
        }

        public static List<E_ShoppingCartTable> GetAllCartDetails(int CartId)
        {
            List<E_ShoppingCartTable> CartList = new List<E_ShoppingCartTable>();

            try
            {
                CartList = ShoppingCartOperation.GetAllCartDetails(CartId);
            }
            catch (ShoppingCartException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return CartList;
        }

        public static int DeleteItemInCart(int RecordId)
        {
            int records = 0;

            try
            {
                records = ShoppingCartOperation.DeleteItemInCart(RecordId);
            }
            catch (ShoppingCartException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return records;
        }

        public static int UpdateCart(E_ShoppingCartTable updatedcart)
        {
            int records = 0;

            try
            {

                records = ShoppingCartOperation.UpdateCart(updatedcart);
               
            }
            catch (ShoppingCartException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return records;
        }

         public static decimal GetTotal(int ShoppingCartId)
         {
            return ShoppingCartOperation.GetTotal(ShoppingCartId);
         }

    }
}
