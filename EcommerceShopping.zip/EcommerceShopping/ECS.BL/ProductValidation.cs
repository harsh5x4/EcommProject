﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ECS.Entity;
using ECS.Exception;
using ECS.DAL;

namespace ECS.BL
{
    public class ProductValidation
    {
        public static List<E_ProductTable> GetProductList(int CatId)
        {
            List<E_ProductTable> ProdList = new List<E_ProductTable>();

            try
            {
                ProdList = ProductOperation.GetProductList(CatId);
            }
            catch (ProductException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return ProdList;
        }


        public static E_ProductTable SearchProduct(string name)
        {
            E_ProductTable prod = null;

            try
            {
                prod = ProductOperation.SearchProduct(name);
            }
            catch (ProductException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return prod;
        }


    }
}
