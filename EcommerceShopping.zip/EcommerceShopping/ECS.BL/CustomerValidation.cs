﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ECS.Entity;
using ECS.Exception;
using ECS.DAL;
using System.Text.RegularExpressions;

namespace ECS.BL
{
    public class CustomerValidation
    {
        public static bool ValidateCustomer(E_CustomerTable cust)
        {
            bool custValidated = true;
            StringBuilder message = new StringBuilder();

            try
            {
                if (!Regex.IsMatch(cust.FullName, "[A-Za-z]+"))
                {
                    message.Append("Customer Name should have alphabets only.");
                    custValidated = false;
                }

                else if (cust.FullName.Trim() == String.Empty)
                {
                    message.Append(" Customer Name should be provided.");
                    custValidated = false;
                }

                if (!Regex.IsMatch(cust.Email, "[a-z@]+"))
                {
                    message.Append(" Email Id should be proper");
                    custValidated = false;
                }

                else if (cust.Email.Trim() == String.Empty)
                {
                    message.Append(" Customer Email should be provided.");
                    custValidated = false;
                }

                if (!Regex.IsMatch(cust.Password, "((?=.*[0-9])(?=.*[a-z])(?=.*[@#$%]).{6,20})"))
                {
                    message.Append(" Password should be alphanumeric, consists of atleast one special character, minimum 6 characters and maximum 20 characters long.");
                    custValidated = false;
                }

                else if (cust.Password.Trim() == String.Empty)
                {
                    message.Append(" Password should be provided.");
                    custValidated = false;
                }

                if (cust.Address.Trim() == String.Empty)
                {
                    message.Append(" Address should be provided.");
                    custValidated = false;
                }

                if (!Regex.IsMatch(cust.Contact.ToString(), "[0-9]{10}"))
                {
                    message.Append(" Contact should have numbers only and should be 10 digit.");
                    custValidated = false;
                }

                else if (cust.Contact.ToString().Trim() == String.Empty)
                {
                    message.Append(" Contact should be provided.");
                    custValidated = false;
                }


                if (custValidated == false)
                    throw new CustomerException(message.ToString());
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return custValidated;
        }

        public static int AddCustomer(E_CustomerTable cust)
        {
            int records = 0;

            try
            {
                if (ValidateCustomer(cust))
                {
                    records = CustomerOperation.AddCustomer(cust);
                }
                else
                    throw new CustomerException("Please provide valid information");
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return records;
        }

        public static E_CustomerTable SearchCustomer(string email, string pwd)
        {
            E_CustomerTable cust = null;

            try
            {
                cust = CustomerOperation.SearchCustomer(email, pwd);
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return cust;
        }

        public static E_CustomerTable SearchCustomerByNo(Int64 Number)
        {
            E_CustomerTable cust = null;

            try
            {
                cust = CustomerOperation.SearchCustomerByNo(Number);
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return cust;
        }
    }
}
