﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ECS.Entity;
using ECS.Exception;
using ECS.DAL;

namespace ECS.BL
{
    public class OrderValidation
    {
        public static int AddOrder(E_OrderTable OrdTab)
        {
            int records = 0;

            try
            {
                records = OrderOperation.AddOrder(OrdTab);

            }

            catch (SystemException ex)
            {
                throw ex;
            }

            return records;
        }


        public static List<E_OrderTable> GetOrder(int CustId)
        {
            List<E_OrderTable> OrderList = new List<E_OrderTable>();

            try
            {
                OrderList = OrderOperation.GetOrder(CustId);
            }

            catch (SystemException ex)
            {
                throw ex;
            }

            return OrderList;
        }
    }
}
