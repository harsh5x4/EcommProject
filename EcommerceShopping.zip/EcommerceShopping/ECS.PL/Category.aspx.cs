﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ECS.Entity;
using ECS.Exception;
using ECS.BL;



namespace ECS.PL
{
    public partial class Category : System.Web.UI.Page
    {
        
        
        private void PopulateCategoryView()
        {
            try
            {
                List<E_CategoryTable> CatList = CategoryValidation.GetAllCategories();

                grdCategory.DataSource = CatList.ToList();
                grdCategory.DataBind();

            }

            catch (CategoryException ex)
            {
                Response.Write(ex.Message);
            }

            catch (SystemException ex)
            {
                Response.Write(ex.Message);
            }
        }

     
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
                PopulateCategoryView();
            else
                grdProduct.Visible = true;
        }


        protected void LinkButton1_Click(object sender, CommandEventArgs e)
        {
            int id = Convert.ToInt32(e.CommandArgument.ToString());
            try
            {
                List<E_ProductTable> ProdList = ProductValidation.GetProductList(id);
                grdProduct.DataSource = ProdList.ToList();
                grdProduct.DataBind();
            }

            catch (ProductException ex)
            {
                Response.Write(ex.Message);
            }

            catch (SystemException ex)
            {
                Response.Write(ex.Message);
            }
        }

       
       
    }
}