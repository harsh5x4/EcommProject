﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ECS.Entity;
using ECS.Exception;
using ECS.BL;
using System.Data;

namespace ECS.PL
{
    public partial class ShoppingCart : System.Web.UI.Page
    {

      
        protected void Page_Load(object sender, EventArgs e)
        {
             E_ShoppingCartTable newcart = (E_ShoppingCartTable)Session["Cart"];

            if (!IsPostBack)
            {
                if (newcart == null)
                {
                    CheckOutBtn.Visible = false;
                    UpdateBtn.Visible = false;
                    lblOrderTotal.Visible = false;
                    
                    lblEmpty.Text = "Your Cart Is Empty!!";

                }

                else
                {
                   int id = (int)newcart.CartId;

                    grdCartList.DataSource = ShoppingCartValidation.GetAllCartDetails(id);
                    grdCartList.DataBind();

                    lblTotal.Text = ShoppingCartValidation.GetTotal(id).ToString();
                    Session["TotalCost"] = lblTotal.Text;
                   
                }
            }


        }


        protected void UpdateBtn_Click(object sender, EventArgs e)
        {
            E_ShoppingCartTable newcart = (E_ShoppingCartTable)Session["Cart"];
            int id = (int)newcart.CartId;



            for (int i = 0; i < grdCartList.Rows.Count; i++)
            {
                GridViewRow gRow = grdCartList.Rows[i];

                TextBox txtbox1 = (TextBox)gRow.FindControl("txtQuantity");
                string s = txtbox1.Text.Trim();

                Label lb = (Label)gRow.FindControl("lblSubTotal");
                

                Label lb1 = (Label)gRow.FindControl("lblPrice");
                string ucost = lb1.Text;

                lb.Text = (Convert.ToInt32(s) * Convert.ToDecimal(ucost)).ToString();
              

                List<E_ShoppingCartTable> updatecartlist = ShoppingCartValidation.GetAllCartDetails(id);
                E_ShoppingCartTable upcart = updatecartlist[i];

                        upcart.Quantity = Convert.ToInt32(s);
                        upcart.SubTotal = Convert.ToDecimal(lb.Text);
                        ShoppingCartValidation.UpdateCart(upcart);
                 
           
                lblTotal.Text = ShoppingCartValidation.GetTotal(id).ToString();
                Session["TotalCost"] = lblTotal.Text;
                
                //ShoppingCartValidation.UpdateCart(newcart);

            }

            //foreach (GridViewRow gdrow in grdCartList.Rows)
            //{
                        
            //    //Searching CheckBox("chkDel") in an individual row of Grid  
            //    //CheckBox chkdel = (CheckBox)gdrow.FindControl("chk1");
            //    CheckBox cb1 = (CheckBox)gdrow.Cells[5].Controls[1];
                
            //    //int ProdId = Convert.ToInt32(grdCartList.DataKeys[gdrow.RowIndex].Value);
            //    //Label lb = (Label)gdrow.FindControl("lblProductId");
            //    //int ProdId = Convert.ToInt32(lb.Text);
            //    //If CheckBox is checked than delete the record with particular ProdId  
            //    if (cb1.Checked)
            //    {
            //        string id1 = gdrow.Cells[0].Text;
            //        int ProdId = Convert.ToInt32(id1);
            //        ShoppingCartValidation.DeleteItemInCart(ProdId);
            //    }
            //}  
        }

        protected void grdCartList_RowDelete(object sender, GridViewDeleteEventArgs e)
        {

            Label lb = (Label)grdCartList.Rows[e.RowIndex].FindControl("lblRecordId");
            int id = Convert.ToInt32(lb.Text);
            int records = ShoppingCartValidation.DeleteItemInCart(id);
            if (records > 0)
            {
                Response.Redirect("ShoppingCart.aspx");
            }


        }

        public const string OrderSessionKey = "OrderId";
        public string GetOrderId()
        {
            if (HttpContext.Current.Session[OrderSessionKey] == null)
            {
                if (!string.IsNullOrWhiteSpace(HttpContext.Current.User.Identity.Name))
                {
                    HttpContext.Current.Session[OrderSessionKey] = HttpContext.Current.User.Identity.Name;
                }
                else
                {
                    // Generate a new random GUID using System.Guid class.     
                    //Guid tempCartId = Guid.NewGuid();
                    Random random = new Random();
                    int i = random.Next(100, 1000);

                    HttpContext.Current.Session[OrderSessionKey] = i.ToString();
                }
            }
            return HttpContext.Current.Session[OrderSessionKey].ToString();
        }

        protected void CheckOutBtn_Click(object sender, EventArgs e)
        {
            E_ShoppingCartTable newcart = (E_ShoppingCartTable)Session["Cart"];
            int id = (int)newcart.CartId;

            List<E_ShoppingCartTable> cart = ShoppingCartValidation.GetAllCartDetails(id);
            int OrderId = Convert.ToInt32(GetOrderId());
            List<int> id1=new List<int>();
            foreach (var item in cart)
	        {
                id1.Add(item.ProductId);    
	        }
             
            
            var OrderDetails = OrderDetailsValidation.GetOrderDetails(OrderId).SingleOrDefault(c => c.OrderId == OrderId);
            if (OrderDetails == null)
            {
                int records=0;
                for (int i = 0; i < cart.Count; i++)
                {
                    OrderDetails = new E_OrderDetailsTable();
                    {

                        OrderDetails.ProductId = id1[i];
                        OrderDetails.OrderId = OrderId;
                        OrderDetails.ProductName = cart[i].ProductName;
                        OrderDetails.UnitCost = (decimal)cart[i].UnitCost;
                        OrderDetails.Quantity = cart[i].Quantity;

                    };
                    records += OrderDetailsValidation.AddOrderDetails(OrderDetails);
                }         
           
                if (records > 0)
                {

                    Session["Order"] = OrderDetails;
                    

                    Response.Redirect("OrderDetails.aspx");
                }
            }

        }

       
    }
}