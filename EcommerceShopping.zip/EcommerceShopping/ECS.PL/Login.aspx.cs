﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ECS.Entity;
using ECS.Exception;
using ECS.BL;

namespace ECS.PL
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

          public void Clear()
        {
            txtEmail.Text = "";
            txtPassword.Text = "";
        }

       

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                string email = txtEmail.Text;
                string password = txtPassword.Text;
                E_CustomerTable cust = CustomerValidation.SearchCustomer(email, password);

                if (cust != null)
                {

                    Session["Login"] = cust;
                    Response.Redirect("Home.aspx");
                    Clear();
                   
                }

                else
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "e1", "alert('Please enter valid User Name and Password')", true);
                //throw new CustomerException("Please enter valid User Name and Password");
            }

            catch (CustomerException ex)
            {
                Response.Write(",<script>alert('" + ex.Message + "');</script>");
            }

            catch (SystemException ex)
            {
                Response.Write(",<script>alert('" + ex.Message + "');</script>");
            }
        }

        protected void btnRegister_Click(object sender, EventArgs e)
        {
            Response.Redirect("Register.aspx");
            Clear();
        }

        

       
    }
    
}