﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ECS.Entity;
using ECS.Exception;
using ECS.BL;
using System.Data;
namespace ECS.PL
{
    public partial class Product : System.Web.UI.Page
    {
        string name;
        E_ProductTable prod = new E_ProductTable();
        E_ShoppingCartTable cartItem = new E_ShoppingCartTable();
        
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                name = Request["ProdName"];
                prod = ProductValidation.SearchProduct(name);
            
                txtProdId.Text = prod.ProductId.ToString();
                txtProdName.Text = prod.ProductName;
                txtModelNo.Text = prod.ModelNo.ToString();
                txtUnitCost.Text = prod.UnitCost.ToString();
                txtDes.Text = prod.ProductDescription;
               
            }

            catch(ProductException ex)
            {
                Response.Write(ex.Message);
            }

            catch (SystemException ex)
            {
                Response.Write(ex.Message);
            }
           
        }

        public const string CartSessionKey = "CartId";
        public string GetCartId()
        {
            if (HttpContext.Current.Session[CartSessionKey] == null)
            {
                if (!string.IsNullOrWhiteSpace(HttpContext.Current.User.Identity.Name))
                {
                    HttpContext.Current.Session[CartSessionKey] = HttpContext.Current.User.Identity.Name;
                }
                else
                {
                    // Generate a new random GUID using System.Guid class.     
                    //Guid tempCartId = Guid.NewGuid();
                    Random random = new Random();
                    int i = random.Next(1,1000);

                    HttpContext.Current.Session[CartSessionKey] = i.ToString();
                }
            }
            return HttpContext.Current.Session[CartSessionKey].ToString();
        }
      
        protected void btnAdd_Click(object sender, EventArgs e)
        {
            // Retrieve the product from the database.           
            int ShoppingCartId = Convert.ToInt32(GetCartId());
            int id = prod.ProductId;

            var cartItem = ShoppingCartValidation.GetAllCartDetails(ShoppingCartId).SingleOrDefault(c => c.CartId == ShoppingCartId && c.ProductId == id);

            if(cartItem==null)
            {
                // Create a new cart item if no cart item exists.                 
                cartItem = new E_ShoppingCartTable();
                {

                    cartItem.ProductId = id;
                    cartItem.CartId = ShoppingCartId;
                    cartItem.Quantity = 1;
                    cartItem.DateCreated = DateTime.Now;
                    cartItem.ProductName = prod.ProductName;
                    cartItem.UnitCost = (decimal)prod.UnitCost;
                    cartItem.SubTotal = cartItem.Quantity * cartItem.UnitCost;
                    
                };

                int records= ShoppingCartValidation.AddToShoppingCart(cartItem);
                



                if (records > 0)
                {
                  
                    Session["Cart"] = cartItem;
                   
                    Response.Redirect("ShoppingCart.aspx");

                  
                }
                else
                    throw new ShoppingCartException("Product Not Added.");
            }
            else
            {
                // If the item does exist in the cart,                  
                // then add one to the quantity.                 
                cartItem.Quantity++;
                cartItem.SubTotal = cartItem.Quantity * cartItem.UnitCost;
                EcomEntities context = new EcomEntities();
                //context.E_ShoppingCartTable.Add(cartItem);
                int records = ShoppingCartValidation.UpdateCart(cartItem);
               //int records= context.SaveChanges();
               if (records > 0)
               {
                
                   Session["Cart"] = cartItem;

                   Response.Redirect("ShoppingCart.aspx");

               }
               else
                   throw new ShoppingCartException("Product Not Added.");
            }
            
        }

       
        }



    }
