﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ECS.Entity;
using ECS.Exception;
using ECS.BL;

namespace ECS.PL
{
    public partial class Confirm : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            E_OrderDetailsTable NewOrdDetails = (E_OrderDetailsTable)Session["Order"];
            //string newcost =Session["TotalCost"].ToString();
            int id = (int)NewOrdDetails.OrderId;
            lblOrderId.Text = id.ToString();
            lblOrderDate.Text = DateTime.Today.ToString();
            lblShipDate.Text =  (DateTime.Today.AddDays(5)).ToString();
          }

        protected void hlSignOut_Click(object sender, EventArgs e)
        {
            Session.Abandon();

            Response.Redirect("Login.aspx");
        }
    }
}