﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ECS.Entity;
using ECS.Exception;
using ECS.BL;

namespace ECS.PL
{
    public partial class OrderDetails : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                E_OrderDetailsTable NewOrdDetails = (E_OrderDetailsTable)Session["Order"];
                //string newcost =Session["TotalCost"].ToString();
                int id = (int)NewOrdDetails.OrderId;

                lblOrderId.Text=id.ToString();
                grdOrderDetails.DataSource = OrderDetailsValidation.GetOrderDetails(id);
                grdOrderDetails.DataBind();

                string cost = (string)Session["TotalCost"];
                lblCost.Text = cost;

            }
        }

        protected void btnConfirm_Click(object sender, EventArgs e)
        {
            E_OrderTable ordtable = new E_OrderTable();
            E_CustomerTable newcust = (E_CustomerTable)Session["Login"];
            E_OrderDetailsTable NewOrdDetails = (E_OrderDetailsTable)Session["Order"];
            try
            {
                ordtable.CustomerId = newcust.CustomerId;
                ordtable.OrderId = NewOrdDetails.OrderId;
                ordtable.OrderDate = DateTime.Today;
                ordtable.ShipDate = DateTime.Today.AddDays(5);
                int records = OrderValidation.AddOrder(ordtable);

                if(records>0)
                {
                    Response.Redirect("Confirm.aspx");
                }

            }
            catch(SystemException ex)
            {
                Response.Write(ex.Message);
            }
        }


    }
}