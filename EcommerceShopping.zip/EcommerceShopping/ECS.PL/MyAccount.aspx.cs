﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ECS.Entity;
using ECS.Exception;
using ECS.BL;

namespace ECS.PL
{
    public partial class MyAccount : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                E_CustomerTable newcust = (E_CustomerTable)Session["Login"];
                int id = newcust.CustomerId;
                grdHistory.DataSource = OrderValidation.GetOrder(id);
                grdHistory.DataBind();
            }
        }

        protected void btnOrderId_Command(object sender, CommandEventArgs e)
        {
            int id = Convert.ToInt32(e.CommandArgument.ToString());
            try
            {
                List<E_OrderDetailsTable> OrderList=  OrderDetailsValidation.GetOrderDetails(id);
                grdOrderDetails.DataSource = OrderList.ToList();
                grdOrderDetails.DataBind();
            }

            catch (SystemException ex)
            {
                Response.Write(ex.Message);
            }

        }
    }
}