﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Threading;
using System.Web.UI.WebControls;
using ECS.Entity;
using ECS.Exception;
using ECS.BL; 


namespace ECS.PL
{
    public partial class Register : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        public void Clear()
        {
            txtName.Text = "";
            txtEmail.Text = "";
            txtPassword.Text = "";
            txtAddress.Text = "";
            txtNumber.Text = "";
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                E_CustomerTable cust = new E_CustomerTable();
                cust.FullName = txtName.Text;
                cust.Email = txtEmail.Text;
                cust.Password = txtPassword.Text;
                cust.Address = txtAddress.Text;
                cust.Contact = Convert.ToInt64(txtNumber.Text);

                E_CustomerTable newcust= CustomerValidation.SearchCustomerByNo(Convert.ToInt64(txtNumber.Text));
                if (newcust == null)
                {
                    int records = CustomerValidation.AddCustomer(cust);

                    if (records > 0)
                    {
                        //Response.Write("<script>window.alert('Your Message');window.location='Login.aspx';</script>");
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "e4", "alert('Registeration Successful')", true);
                        //Thread.Sleep(5000);
                        Response.Redirect("Login.aspx");
                        Clear();
                    }
                }
                else
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "e2", "alert('Contact Number Already Exists. Please Provide Different Contact Number')", true);
                    //throw new CustomerException("Contact Number Already Exists. Please Provide Different Contact Number.");
            }
            catch (CustomerException ex)
            {
                Response.Write(",<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write(",<script>alert('" + ex.Message + "');</script>");
            }
        }
    }
}